# AI CV Pro

FastAPI application for AI-powered resume analysis and rewriting.

## Setup

```bash
pip install -r requirements.txt
uvicorn aicv2:app --reload
```
